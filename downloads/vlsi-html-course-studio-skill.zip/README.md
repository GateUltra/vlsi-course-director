# VLSI HTML Course Studio 2.0.0

Copy the complete `vlsi-html-course-studio` directory into your skill location, or run its production tools directly. Start with `vlsi-html-course-studio/SKILL.md` and `references/reproduce-v2.md`.

The package contains a stable HTML/SVG runtime, a complete narrated production CLI, two independently modeled course packs, twelve fixed English/Chinese speech clips, domain/contract/browser tests and the preserved Placement source reference. Fixture builds need no online speech service. Dependencies and finished videos are not bundled; follow the isolated setup commands to generate MP4/WebM, subtitles and the interactive site.

`docs/HTML_STUDIO_V2_VALIDATION.md` records executed checks and limits. Older full lessons and historical reports are clearly separate from the short engineering benchmarks. The original director skill and v1 archive remain in the public repository: https://github.com/GateUltra/vlsi-course-director

Read LICENSE and THIRD_PARTY_NOTICES.md before redistributing historical third-party source or assets. Current sample narration provenance is recorded per clip.

# VLSI HTML Course Studio / VLSI课程制作技能

This standalone package contains the new skill, its detailed references, portable tools, a runnable silent starter, and a source-only Placement worked example. The original vlsi-course-director skill remains available separately in the repository.

这是新版独立包。请从 vlsi-html-course-studio/SKILL.md 开始阅读；详细指南用中文，代码和教学界面示例用英文。旧版保留在公开仓库中。

- [Skill entry / 技能入口](vlsi-html-course-studio/SKILL.md)
- [Repository and original skill / 仓库与旧版](https://github.com/GateUltra/vlsi-course-director)
- [Installation and English guide / 安装与用法](https://github.com/GateUltra/vlsi-course-director/blob/main/docs/HTML_STUDIO_GUIDE.md)
- [中文介绍](https://github.com/GateUltra/vlsi-course-director/blob/main/README.zh-CN.md)

Copy the complete skill folder to your agent's skill directory. For a project-local Codex installation, use .agents/skills/vlsi-html-course-studio; preserve all subfolders. Alternatively ask Codex's bundled skill-installer to install https://github.com/GateUltra/vlsi-course-director/tree/main/vlsi-html-course-studio. See https://learn.chatgpt.com/docs/build-skills for current discovery instructions.

Quick start from this extracted folder, with Python 3.10+:

```powershell
python vlsi-html-course-studio/scripts/init_course.py --destination ../my-vlsi-lesson --title "My VLSI Studio"
python vlsi-html-course-studio/scripts/serve_site.py --directory ../my-vlsi-lesson --port 8780
```

Open http://127.0.0.1:8780/. This is a 32-second silent provisional storyboard, not a narrated movie. The destination must not already exist. No online TTS is called. Production dependencies and rendering commands are in references/tooling.md inside the skill.

The Placement source example omits final MP4s and raw audio; its SNAPSHOT_README.md explains the historical configuration and omitted inputs. Original skill/helper/starter files use the included MIT license; preserve the separate third-party provenance in THIRD_PARTY_NOTICES.md and the example CREDITS.md.
